package com.dalilbaqubah.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.OnMapReadyCallback
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Prototype of an Iraq-wide native navigation app.
 * Map display uses MapLibre + OpenStreetMap tiles; route demo uses OSRM public demo server.
 */
class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mapView: MapView
    private lateinit var destinationInput: EditText
    private lateinit var statusText: TextView
    private var map: MapLibreMap? = null
    private var loadedStyle: Style? = null
    private var currentLocation: Location? = null
    private var destination: LatLng? = null
    private var destinationName: String = "الوجهة المحددة على الخريطة"
    private var locationManager: LocationManager? = null
    private var tts: TextToSpeech? = null
    private var speechReady = false
    private var isNavigating = false
    private var centerOnNextFix = false
    private var nextInstructionIndex = 0
    private var routeSteps: List<VoiceStep> = emptyList()
    private var pendingAction = PendingAction.NONE
    private val iraqCenter = LatLng(33.0, 43.5)
    private val locationRequestCode = 401

    private enum class PendingAction { NONE, SHOW_LOCATION, START_NAVIGATION }
    private data class VoiceStep(val point: LatLng, val text: String, val isArrival: Boolean)
    private data class RouteResult(
        val geometry: List<Point>,
        val steps: List<VoiceStep>,
        val distanceMeters: Double,
        val durationSeconds: Double
    )

    private val locationListener = LocationListener { location -> handleLocation(location) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        tts = TextToSpeech(this) { result ->
            runOnUiThread {
                val engine = tts
                if (result == TextToSpeech.SUCCESS && engine != null) {
                    val languageResult = engine.setLanguage(Locale("ar"))
                    speechReady = languageResult != TextToSpeech.LANG_MISSING_DATA &&
                        languageResult != TextToSpeech.LANG_NOT_SUPPORTED
                    engine.setSpeechRate(0.98f)
                    engine.setPitch(0.96f)
                    if (!speechReady) {
                        Toast.makeText(this, "محرك الصوت العربي غير متوفر. فعّل صوتاً عربياً من إعدادات تحويل النص إلى كلام", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 248))
        }
        val header = TextView(this).apply {
            text = "دليل العراق  •  الملاحة الصوتية"
            textSize = 21f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(8, 127, 140))
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            setPadding(24, 20, 24, 20)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        destinationInput = EditText(this).apply {
            hint = "اكتب وجهتك داخل العراق"
            textSize = 16f
            singleLine = true
            setPadding(18, 8, 18, 8)
            setBackgroundColor(Color.WHITE)
        }
        val searchButton = Button(this).apply {
            text = "بحث"
            setOnClickListener {
                val query = destinationInput.text.toString().trim()
                if (query.isBlank()) {
                    Toast.makeText(this@MainActivity, "اكتب اسم مدينة أو مكان", Toast.LENGTH_SHORT).show()
                } else {
                    searchDestination(query)
                }
            }
        }
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 6, 8, 6)
            addView(destinationInput, LinearLayout.LayoutParams(0, -2, 1f))
            addView(searchButton, LinearLayout.LayoutParams(-2, -2))
        }
        root.addView(searchRow)

        statusText = TextView(this).apply {
            text = "ابحث عن وجهة، أو اضغط على الخريطة لتحديدها."
            textSize = 14f
            setTextColor(Color.rgb(45, 55, 60))
            setPadding(14, 8, 14, 8)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2))

        mapView = MapView(this)
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))

        val primaryActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(4, 4, 4, 0)
            setBackgroundColor(Color.WHITE)
        }
        primaryActions.addView(makeButton("موقعي") { requestLocationAction(PendingAction.SHOW_LOCATION) }, LinearLayout.LayoutParams(0, -2, 1f))
        primaryActions.addView(makeButton("ابدأ الملاحة") { requestLocationAction(PendingAction.START_NAVIGATION) }, LinearLayout.LayoutParams(0, -2, 1f))
        primaryActions.addView(makeButton("إيقاف") { stopNavigation() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(primaryActions)

        val secondaryActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(4, 0, 4, 4)
            setBackgroundColor(Color.WHITE)
        }
        secondaryActions.addView(makeButton("تجربة الصوت") { speak("أهلاً بك في دليل العراق. الملاحة الصوتية جاهزة.") }, LinearLayout.LayoutParams(0, -2, 1f))
        secondaryActions.addView(makeButton("إبلاغ عن حادث") {
            Toast.makeText(this@MainActivity, "البلاغات المشتركة بين المستخدمين ستضاف في مرحلة لاحقة", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(secondaryActions)

        val attribution = TextView(this).apply {
            text = "الخريطة © OpenStreetMap contributors  •  التوجيه التجريبي عبر OSRM"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 4)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(attribution, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setOnClickListener { action() }
    }

    override fun onMapReady(mapLibreMap: MapLibreMap) {
        map = mapLibreMap
        mapLibreMap.cameraPosition = CameraPosition.Builder().target(iraqCenter).zoom(5.0).build()
        val styleJson = """{
          "version": 8,
          "sources": {
            "osm": {
              "type": "raster",
              "tiles": ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
              "tileSize": 256,
              "attribution": "© OpenStreetMap contributors"
            }
          },
          "layers": [{"id":"osm-layer","type":"raster","source":"osm","minzoom":0,"maxzoom":19}]
        }"""
        mapLibreMap.setStyle(styleJson) { style ->
            loadedStyle = style
            style.addSource(GeoJsonSource(ROUTE_SOURCE_ID, FeatureCollection.fromFeatures(emptyArray<Feature>())))
            style.addLayer(
                LineLayer(ROUTE_LAYER_ID, ROUTE_SOURCE_ID).withProperties(
                    PropertyFactory.lineColor(Color.rgb(0, 136, 255)),
                    PropertyFactory.lineWidth(6f),
                    PropertyFactory.lineOpacity(0.92f)
                )
            )
            style.addSource(GeoJsonSource(DESTINATION_SOURCE_ID, FeatureCollection.fromFeatures(emptyArray<Feature>())))
            style.addLayer(
                CircleLayer(DESTINATION_LAYER_ID, DESTINATION_SOURCE_ID).withProperties(
                    PropertyFactory.circleColor(Color.rgb(229, 57, 53)),
                    PropertyFactory.circleRadius(8f),
                    PropertyFactory.circleStrokeColor(Color.WHITE),
                    PropertyFactory.circleStrokeWidth(2f)
                )
            )
            mapLibreMap.addOnMapClickListener { tappedPoint ->
                destination = tappedPoint
                destinationName = "الوجهة المحددة على الخريطة"
                updateDestinationMarker(tappedPoint)
                statusText.text = "تم تحديد الوجهة على الخريطة. اضغط «ابدأ الملاحة»."
                true
            }
        }
    }

    private fun searchDestination(query: String) {
        statusText.text = "جاري البحث عن: $query"
        thread(name = "dalil-geocoder") {
            try {
                val geocoder = Geocoder(this@MainActivity, Locale("ar"))
                @Suppress("DEPRECATION")
                val results: List<Address>? = geocoder.getFromLocationName("$query, Iraq", 1)
                val address = results?.firstOrNull()
                runOnUiThread {
                    if (address == null) {
                        statusText.text = "لم أجد المكان. جرّب اسم مدينة/حي أو اضغط مكانه على الخريطة."
                    } else {
                        val point = LatLng(address.latitude, address.longitude)
                        destination = point
                        destinationName = address.featureName?.takeIf { it.isNotBlank() } ?: query
                        updateDestinationMarker(point)
                        map?.animateCamera(CameraUpdateFactory.newLatLngZoom(point, 15.0))
                        statusText.text = "الوجهة: ${address.getAddressLine(0) ?: destinationName}. اضغط «ابدأ الملاحة»."
                    }
                }
            } catch (exception: Exception) {
                runOnUiThread {
                    statusText.text = "البحث غير متاح على هذا الجهاز الآن. حرّك الخريطة واضغط موقع الوجهة."
                }
            }
        }
    }

    private fun updateDestinationMarker(point: LatLng) {
        val source = loadedStyle?.getSourceAs<GeoJsonSource>(DESTINATION_SOURCE_ID) ?: return
        val feature = Feature.fromGeometry(Point.fromLngLat(point.longitude, point.latitude))
        source.setGeoJson(FeatureCollection.fromFeature(feature))
    }

    private fun requestLocationAction(action: PendingAction) {
        if (action == PendingAction.START_NAVIGATION && destination == null) {
            statusText.text = "حدد وجهة بالبحث أو بالضغط على الخريطة أولاً."
            speak("حدد وجهتك أولاً")
            pendingAction = PendingAction.NONE
            return
        }
        val hasFine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) {
            pendingAction = action
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                locationRequestCode
            )
            return
        }
        pendingAction = action
        centerOnNextFix = action == PendingAction.SHOW_LOCATION
        startLocationUpdates()
        val lastKnown = getLastKnownLocation()
        if (lastKnown != null) {
            currentLocation = lastKnown
            if (centerOnNextFix) {
                map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(lastKnown.latitude, lastKnown.longitude), 16.0))
                centerOnNextFix = false
            }
        }
        if (action == PendingAction.START_NAVIGATION) {
            val location = currentLocation
            if (location != null) {
                pendingAction = PendingAction.NONE
                calculateRoute(location, destination)
            } else {
                pendingAction = PendingAction.START_NAVIGATION
                statusText.text = "أنتظر إشارة GPS حتى أحدد موقع البداية..."
            }
        } else {
            pendingAction = PendingAction.NONE
            if (action == PendingAction.SHOW_LOCATION && currentLocation == null) {
                statusText.text = "جاري تحديد موقعك. تأكد من تشغيل GPS."
            }
        }
    }

    private fun startLocationUpdates() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        locationManager = manager
        try {
            manager.removeUpdates(locationListener)
            for (provider in manager.getProviders(true)) {
                try { manager.requestLocationUpdates(provider, 2500L, 5f, locationListener) } catch (_: Exception) { }
            }
        } catch (_: SecurityException) { }
    }

    private fun getLastKnownLocation(): Location? {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        return try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            manager.getProviders(true).mapNotNull { provider ->
                try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
            }.minByOrNull { it.accuracy }
        } catch (_: Exception) { null }
    }

    private fun handleLocation(location: Location) {
        currentLocation = location
        if (centerOnNextFix || isNavigating) {
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(location.latitude, location.longitude), 16.0))
            centerOnNextFix = false
        }
        if (pendingAction == PendingAction.START_NAVIGATION && destination != null) {
            pendingAction = PendingAction.NONE
            calculateRoute(location, destination)
        }
        if (isNavigating) processVoiceGuidance(location)
    }

    private fun calculateRoute(start: Location, destinationPoint: LatLng?) {
        if (destinationPoint == null) {
            statusText.text = "حدد وجهة بالبحث أو بالضغط على الخريطة أولاً."
            speak("حدد وجهتك أولاً")
            return
        }
        statusText.text = "جاري حساب الطريق إلى $destinationName..."
        thread(name = "dalil-route") {
            var connection: HttpURLConnection? = null
            try {
                val routeUrl = "https://router.project-osrm.org/route/v1/driving/" +
                    "${start.longitude},${start.latitude};${destinationPoint.longitude},${destinationPoint.latitude}" +
                    "?overview=full&geometries=geojson&steps=true&alternatives=false"
                connection = (URL(routeUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("User-Agent", "DalilIraqAndroid/1.0")
                }
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val root = JSONObject(response)
                if (root.optString("code") != "Ok") throw IllegalStateException(root.optString("message", "تعذر حساب الطريق"))
                val route = root.getJSONArray("routes").getJSONObject(0)
                val coords = route.getJSONObject("geometry").getJSONArray("coordinates")
                val geometry = ArrayList<Point>(coords.length())
                for (i in 0 until coords.length()) {
                    val coord = coords.getJSONArray(i)
                    geometry.add(Point.fromLngLat(coord.getDouble(0), coord.getDouble(1)))
                }
                val steps = mutableListOf<VoiceStep>()
                val legs = route.getJSONArray("legs")
                for (legIndex in 0 until legs.length()) {
                    val stepsJson = legs.getJSONObject(legIndex).getJSONArray("steps")
                    for (stepIndex in 0 until stepsJson.length()) {
                        val step = stepsJson.getJSONObject(stepIndex)
                        val maneuver = step.getJSONObject("maneuver")
                        val type = maneuver.optString("type", "continue")
                        if (type == "depart") continue
                        val coordinate = maneuver.getJSONArray("location")
                        val place = LatLng(coordinate.getDouble(1), coordinate.getDouble(0))
                        val modifier = maneuver.optString("modifier", "")
                        val exit = if (maneuver.has("exit")) maneuver.optInt("exit", 0) else 0
                        val roadName = step.optString("name", "").trim()
                        val instruction = makeArabicInstruction(type, modifier, exit, roadName)
                        steps.add(VoiceStep(place, instruction, type == "arrive"))
                    }
                }
                val result = RouteResult(geometry, steps, route.optDouble("distance", 0.0), route.optDouble("duration", 0.0))
                runOnUiThread { onRouteReady(result) }
            } catch (exception: Exception) {
                runOnUiThread {
                    statusText.text = "ما قدرت أحسب الطريق الآن. تأكد من الإنترنت وجرّب مرة ثانية."
                    Toast.makeText(this@MainActivity, "تعذر حساب المسار: ${exception.message ?: "خطأ بالشبكة"}", Toast.LENGTH_LONG).show()
                    isNavigating = false
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun makeArabicInstruction(type: String, modifier: String, exit: Int, roadName: String): String {
        val direction = when (modifier) {
            "left" -> "يساراً"
            "right" -> "يميناً"
            "slight left" -> "إلى اليسار قليلاً"
            "slight right" -> "إلى اليمين قليلاً"
            "sharp left" -> "يساراً بشكل حاد"
            "sharp right" -> "يميناً بشكل حاد"
            "straight" -> "إلى الأمام"
            "uturn" -> "استدر للخلف"
            else -> "إلى الأمام"
        }
        val base = when (type) {
            "arrive" -> "وصلت إلى وجهتك"
            "turn" -> "انعطف $direction"
            "end of road" -> "بنهاية الطريق انعطف $direction"
            "fork" -> "عند التفرع ابقَ $direction"
            "merge" -> "اندَمج $direction"
            "on ramp" -> "اسلك المنحدر $direction"
            "off ramp" -> "خذ المخرج $direction"
            "roundabout", "rotary", "roundabout turn" -> if (exit > 0) "ادخل الدوار وخذ المخرج رقم $exit" else "ادخل الدوار"
            "continue", "new name" -> "استمر $direction"
            "notification" -> "تابع السير"
            else -> "تابع الطريق $direction"
        }
        return if (roadName.isNotBlank() && type != "arrive") "$base باتجاه $roadName" else base
    }

    private fun onRouteReady(route: RouteResult) {
        if (route.geometry.size < 2) {
            statusText.text = "المسار غير واضح. جرّب اختيار وجهة ثانية."
            return
        }
        val source = loadedStyle?.getSourceAs<GeoJsonSource>(ROUTE_SOURCE_ID)
        if (source != null) {
            source.setGeoJson(FeatureCollection.fromFeature(Feature.fromGeometry(LineString.fromLngLats(route.geometry))))
        }
        destination?.let { updateDestinationMarker(it) }
        routeSteps = route.steps
        nextInstructionIndex = 0
        isNavigating = true
        centerOnNextFix = true
        val km = String.format(Locale.US, "%.1f", route.distanceMeters / 1000.0)
        val minutes = (route.durationSeconds / 60.0).toInt().coerceAtLeast(1)
        statusText.text = "المسار جاهز: $km كم تقريباً • $minutes دقيقة تقريباً. اتبع التعليمات الصوتية."
        speak("بدأت الملاحة إلى $destinationName. المسافة حوالي $km كيلومتر")
        currentLocation?.let { map?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(it.latitude, it.longitude), 16.0)) }
    }

    private fun processVoiceGuidance(location: Location) {
        if (nextInstructionIndex >= routeSteps.size) return
        val step = routeSteps[nextInstructionIndex]
        val result = FloatArray(1)
        Location.distanceBetween(location.latitude, location.longitude, step.point.latitude, step.point.longitude, result)
        val distance = result[0]
        if (step.isArrival) {
            if (distance <= 70f) {
                speak("وصلت إلى وجهتك")
                statusText.text = "وصلت إلى الوجهة. انتهت الملاحة."
                isNavigating = false
                nextInstructionIndex = routeSteps.size
            }
        } else if (distance <= 320f) {
            speak(step.text)
            statusText.text = "التوجيه التالي: ${step.text}"
            nextInstructionIndex++
        }
    }

    private fun speak(message: String) {
        val engine = tts
        if (engine != null && speechReady) {
            engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, "dalil-${System.currentTimeMillis()}")
        } else {
            Toast.makeText(this, "الصوت العربي غير جاهز بعد. جرّب زر «تجربة الصوت» أو فعّل الصوت العربي في إعدادات الجهاز.", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopNavigation() {
        if (isNavigating) speak("تم إيقاف الملاحة")
        isNavigating = false
        routeSteps = emptyList()
        nextInstructionIndex = 0
        loadedStyle?.getSourceAs<GeoJsonSource>(ROUTE_SOURCE_ID)?.setGeoJson(FeatureCollection.fromFeatures(emptyArray<Feature>()))
        statusText.text = "تم إيقاف الملاحة. حدد وجهة جديدة للبدء من جديد."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationRequestCode) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
                val action = pendingAction
                requestLocationAction(action)
            } else {
                pendingAction = PendingAction.NONE
                statusText.text = "لازم تسمح بالوصول للموقع حتى تشتغل الملاحة."
            }
        }
    }

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }

    override fun onDestroy() {
        try { locationManager?.removeUpdates(locationListener) } catch (_: Exception) { }
        tts?.stop()
        tts?.shutdown()
        mapView.onDestroy()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mapView.onSaveInstanceState(outState)
    }

    companion object {
        private const val ROUTE_SOURCE_ID = "dalil-route-source"
        private const val ROUTE_LAYER_ID = "dalil-route-layer"
        private const val DESTINATION_SOURCE_ID = "dalil-destination-source"
        private const val DESTINATION_LAYER_ID = "dalil-destination-layer"
    }
}
